SMODS.Sound{
    key="gooberSell",
    path="gooberSell.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="gooberDecay",
    path="gooberDecay.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="gooberBuy",
    path="gooberBuy.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="yellowfrogCroak",
    path="yellowfrogCroak.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="alexSnort",
    path="alexSnort.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="backyardBurn",
    path="backyardBurn.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="cjExplosion",
    path="cjExplosion.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="cursedDieRoll",
    path="cursedDieRoll.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="dieRoll",
    path="dieRoll.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="cursedLong",
    path="cursedLong.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="cursedShort",
    path="cursedShort.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="gooseHjonk",
    path="gooseHjonk.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="hexCoin",
    path="hexCoin.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="hexDrain",
    path="hexDrain.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="hexRun",
    path="hexRun.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="lexSpawn",
    path="lexSpawn.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="nuclearExplosion",
    path="nuclearExplosion.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="nuclearSiren",
    path="nuclearSiren.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="prismaticCollect",
    path="prismaticCollect.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="rkey",
    path="rkey.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="tokagashiMeep",
    path="tokagashiMeep.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="uncursed",
    path="uncursed.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="creatureSpawn",
    path="creatureSpawn.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="rizz",
    path="rizz.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="sishiKutaro",
    path="sishiKutaro.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="martHorn",
    path="martHorn.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="oldManClick",
    path="oldManClick.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="redborgSpray",
    path="redborgSpray.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="redborgShake",
    path="redborgShake.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="sketchDecay",
    path="sketchDecay.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="spectreBuy",
    path="spectreBuy.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="spectreUpgrade",
    path="spectreUpgrade.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="spectreSold",
    path="spectreSold.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="odyStrike",
    path="odyStrike.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="alexDeath",
    path="alexDeath.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="apple",
    path="apple.ogg",
    pitch=0.7,
    volume=0.6
}